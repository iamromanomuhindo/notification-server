// Initialize the Firebase app with your config object.
firebase.initializeApp({
    apiKey: "AIzaSyC0GLlf0R9zVdr_1Kf5I330GVLwGLpCbJ4",
    authDomain: "manomediapush.firebaseapp.com",
    projectId: "manomediapush",
    storageBucket: "manomediapush.firebasestorage.app",
    messagingSenderId: "555436210817",
    appId: "1:555436210817:web:9990362d0719508f84eb80"
});

// Request notification permission and set up Firebase Messaging.
async function setupPushNotifications() {
    try {
        // Check if messaging is supported
        if (!firebase.messaging.isSupported()) {
            console.error('Firebase messaging is not supported in this browser');
            return;
        }

        const messaging = firebase.messaging();
        
        // Request permission.
        const permission = await Notification.requestPermission();
        console.log("Notification permission:", permission);
        if (permission !== 'granted') {
            throw new Error('Notification permission denied');
        }

        // Get registration token.
        try {
            const currentToken = await messaging.getToken({
                vapidKey: 'BN6qhGtnqlp9bxyakErnWyXIMbUSbS3Ex6uuQaObNrNmbrN3vqyswMVt4R5vsDZDDtnOrKPsb9oAg-TybrmPQZg'
            });

            if (currentToken) {
                // Log the token to the console.
                console.log('FCM Token:', currentToken);

                // Send the token to your server.
                await sendTokenToServer(currentToken);
                updateSubscriptionButton(true);
            } else {
                console.log('No registration token available. Possible causes:');
                console.log('1. Service worker not registered');
                console.log('2. Firebase messaging not properly initialized');
                console.log('3. User blocked notifications');
                updateSubscriptionButton(false);
            }
        } catch (tokenError) {
            console.error('Error getting FCM token:', tokenError);
            updateSubscriptionButton(false);
        }
    } catch (err) {
        console.error('An error occurred while setting up push notifications:', err);
        updateSubscriptionButton(false);
    }
}

// Send FCM token to your server.
async function sendTokenToServer(token) {
    try {
        console.log("Sending token to server:", token);
        const response = await fetch('/api/subscribe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token })
        });
        
        if (!response.ok) {
            throw new Error('Failed to send token to server');
        }
        
        localStorage.setItem('tokenSentToServer', '1');
        console.log('Token successfully sent to server');
    } catch (error) {
        console.error('Error sending token to server:', error);
        localStorage.removeItem('tokenSentToServer');
    }
}

// Update subscription button state.
function updateSubscriptionButton(isSubscribed) {
    const subscribeButton = document.getElementById('pushSubscribeBtn');
    if (subscribeButton) {
        subscribeButton.textContent = isSubscribed ? 'Unsubscribe from Push' : 'Subscribe to Push';
        subscribeButton.disabled = false;
    }
}

// Handle foreground messages.
firebase.messaging().onMessage((payload) => {
    console.log('Message received in foreground:', payload);
    const { title, body } = payload.notification;
    
    // Show notification
    new Notification(title, {
        body: body,
        icon: '/images/heart-icon.png'
    });
});

// Event listener for subscription button and auto-initialization.
document.addEventListener('DOMContentLoaded', () => {
    // Ensure Firebase is initialized before setting up notifications
    if (firebase.apps.length === 0) {
        console.error('Firebase not initialized. Make sure firebase-config.js is loaded first');
        return;
    }
    setupPushNotifications();
});
