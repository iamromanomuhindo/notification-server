// Supabase configuration
const SUPABASE_URL = 'https://jdyugieeawrcbxpoiyho.supabase.co';
const SUPABASE_SERVICE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpkeXVnaWVlYXdyY2J4cG9peWhvIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNzI4NTY3MywiZXhwIjoyMDUyODYxNjczfQ.LjYypQbIYm30-4jgLUg1r8I4Wug5HBEOg_QYPrxQk0M';

// Initialize Supabase client
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
    db: {
        schema: 'public'
    },
    auth: {
        autoRefreshToken: false,
        persistSession: false,
        detectSessionInUrl: false
    }
});

// Abstract API configuration
const ABSTRACT_API_KEYS = [
    { key: '793c930ddc6f43c1bd53173a996206e9', usageCount: 0 },
    // Add more API keys here in the same format
];

const MAX_KEY_USAGE = 900;
let currentKeyIndex = 0;

// Function to get the next available API key
function getNextApiKey() {
    const currentKey = ABSTRACT_API_KEYS[currentKeyIndex];
    
    // Increment usage count
    currentKey.usageCount++;
    
    // If current key has reached limit, rotate to next key
    if (currentKey.usageCount >= MAX_KEY_USAGE) {
        currentKeyIndex = (currentKeyIndex + 1) % ABSTRACT_API_KEYS.length;
        ABSTRACT_API_KEYS[currentKeyIndex].usageCount = 0;
        console.log(`Rotating to next API key. New key index: ${currentKeyIndex}`);
    }
    
    return currentKey.key;
}

// Function to detect device type that matches the enum in the database
function getDeviceType() {
    const ua = navigator.userAgent;
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
        return "tablet";
    }
    if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
        return "mobile";
    }
    return "desktop";
}

// Function to generate a unique device ID
function generateDeviceId() {
    return 'device_' + Math.random().toString(36).substr(2, 9);
}

// Function to check Supabase connection
async function checkSupabaseConnection() {
    try {
        console.log('Testing Supabase connection...');
        const { data, error } = await supabaseClient
            .from('subscribers')
            .select('id')
            .limit(1);
        
        if (error) {
            console.error('Supabase query error:', error);
            return false;
        }
        
        console.log('Supabase connection successful');
        return true;
    } catch (error) {
        console.error('Supabase connection error:', error);
        if (error.message?.includes('ERR_NAME_NOT_RESOLVED')) {
            console.error('DNS resolution failed. Please check your network connection and DNS settings.');
        }
        return false;
    }
}

// Function to get location details using Abstract IP Geolocation API
async function getLocationDetails() {
    try {
        const apiKey = getNextApiKey();
        const response = await fetch(`https://ipgeolocation.abstractapi.com/v1/?api_key=${apiKey}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Location data received:', data);
        
        return {
            country: data.country || 'Unknown',
            city: data.city || 'Unknown',
            latitude: data.latitude || null,
            longitude: data.longitude || null,
            is_vpn: data.security?.is_vpn || false
        };
    } catch (error) {
        console.error('Error fetching location details:', error);
        return {
            country: 'Unknown',
            city: 'Unknown',
            latitude: null,
            longitude: null,
            is_vpn: false
        };
    }
}

// Function to store subscription data in Supabase
async function storeSubscriptionData(fcmToken) {
    try {
        // Check Supabase connection first
        const isConnected = await checkSupabaseConnection();
        if (!isConnected) {
            throw new Error('Cannot connect to Supabase');
        }

        // Get location information using Abstract API
        const location = await getLocationDetails();

        // Prepare the data according to the subscribers table schema
        const subscriberData = {
            id: fcmToken,
            device_id: generateDeviceId(),
            browser: navigator.userAgent,
            country: location.country,
            city: location.city,
            latitude: location.latitude,
            longitude: location.longitude,
            status: 'active', // Using the subscriber_status enum
            last_active_at: new Date().toISOString(),
            created_at: new Date().toISOString(),
            device_type: getDeviceType(), // Using the device_type enum
            is_proxy_or_vpn: location.is_vpn
        };

        console.log('Attempting to store subscriber data:', subscriberData);

        // Using upsert with the proper unique constraint
        const { error: upsertError } = await supabaseClient
            .from('subscribers')
            .upsert(subscriberData, {
                onConflict: 'id'
            });

        if (upsertError) {
            console.error('Supabase error:', upsertError);
            throw upsertError;
        }

        // Verify the data was stored
        const { data: verifyData, error: verifyError } = await supabaseClient
            .from('subscribers')
            .select('*')
            .eq('id', fcmToken)
            .single();

        if (verifyError) {
            console.error('Error verifying data:', verifyError);
            throw verifyError;
        }

        console.log('Successfully stored and verified subscriber:', {
            id: verifyData.id,
            country: verifyData.country,
            city: verifyData.city,
            device_type: verifyData.device_type,
            status: verifyData.status
        });

        return verifyData;
    } catch (error) {
        console.error('Error storing subscriber data:', error);
        if (error.message) console.error('Error message:', error.message);
        if (error.response) console.error('Error response:', error.response);
        throw error;
    }
}

// Listen for FCM token generation
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Wait for Firebase and Supabase to be available
        const checkDependencies = setInterval(async () => {
            if (window.firebase?.messaging && window.supabase) {
                clearInterval(checkDependencies);
                console.log('Dependencies loaded, proceeding with token generation...');
                
                try {
                    const messaging = firebase.messaging();
                    const currentToken = await messaging.getToken({
                        vapidKey: "BN6qhGtnqlp9bxyakErnWyXIMbUSbS3Ex6uuQaObNrNmbrN3vqyswMVt4R5vsDZDDtnOrKPsb9oAg-TybrmPQZg"
                    });

                    if (currentToken) {
                        console.log('FCM Token generated:', currentToken);
                        console.log('Attempting to store in Supabase...');
                        await storeSubscriptionData(currentToken);
                    } else {
                        console.error('No FCM token generated');
                    }
                } catch (tokenError) {
                    console.error('Error generating or storing token:', tokenError);
                }
            }
        }, 1000);

        // Set a timeout to clear the interval if dependencies don't load
        setTimeout(() => {
            clearInterval(checkDependencies);
            console.error('Timeout waiting for dependencies');
        }, 30000); // Increased timeout to 30 seconds
    } catch (error) {
        console.error('Error in subscription process:', error);
    }
});