// content-blocked.js

// Function to create and show the modal with a countdown timer
function showModal() {
    // Prevent duplicate modals by checking if one already exists.
    if (document.getElementById("protected-content-modal")) {
        return;
    }

    const modal = document.createElement("div");
    modal.id = "protected-content-modal";
    modal.style.position = "fixed";
    modal.style.top = "0";
    modal.style.left = "0";
    modal.style.width = "100%";
    modal.style.height = "100%";
    modal.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
    modal.style.display = "flex";
    modal.style.justifyContent = "center";
    modal.style.alignItems = "center";
    modal.style.zIndex = "9999";

    const content = document.createElement("div");
    content.style.backgroundColor = "#ffffff";
    content.style.padding = "40px 60px";
    content.style.borderRadius = "12px";
    content.style.boxShadow = "0 8px 20px rgba(0, 0, 0, 0.2)";
    content.style.maxWidth = "600px";
    content.style.textAlign = "center";

    const title = document.createElement("h2");
    title.textContent = "Access Restricted";
    title.style.color = "#27ae60"; // Green color
    title.style.marginBottom = "20px";

    const message = document.createElement("p");
    if (isSafari()) {
        message.textContent =
            "This website's content is protected. Unfortunately, Safari on iOS does not support web push notifications. Please use another browser to access the full functionality.";
    } else {
        message.textContent = "Allow push notifications to proceed.";
    }
    message.style.color = "#333333";
    message.style.fontSize = "18px";
    message.style.marginBottom = "30px";

    const button = document.createElement("button");
    if (!isSafari()) {
        button.textContent = "Allow Push Notifications";
        button.style.backgroundColor = "#27ae60"; // Green color
        button.style.color = "#ffffff";
        button.style.padding = "15px 30px";
        button.style.border = "none";
        button.style.borderRadius = "5px";
        button.style.cursor = "pointer";
        button.style.fontSize = "16px";
        button.style.transition = "background-color 0.3s ease";

        button.addEventListener("mouseenter", () => {
            button.style.backgroundColor = "#2ecc71"; // Lighter green on hover
        });

        button.addEventListener("mouseleave", () => {
            button.style.backgroundColor = "#27ae60"; // Original green
        });

        button.addEventListener("click", requestPushPermission);
    } else {
        // If Safari, hide the button since it won't work
        button.style.display = "none";
    }

    content.appendChild(title);
    content.appendChild(message);
    if (!isSafari()) {
        content.appendChild(button); // Add button only if not Safari
    }
    modal.appendChild(content);

    document.body.appendChild(modal);

    return { modal };
}

// Function to check if push notifications are already granted
async function checkNotificationPermission() {
    return Notification.permission === "granted";
}

// Function to request push notification permission
async function requestPushPermission(event) {
    event.preventDefault(); // Prevent default navigation behavior
    try {
        const permission = await Notification.requestPermission();
        if (permission === "granted") {
            hideModal();
            unlockFormSubmission();
            // Once permission is granted, redirect to thank-you page.
            window.location.href = 'thank-you.html';
        } else if (permission === "denied") {
            alert("Notifications are blocked. Please enable them to proceed. Click on the padlock icon on the left side of the URL bar to Allow Permission");
            // The modal remains visible until the user grants permission.
        }
    } catch (error) {
        console.error("Error requesting notification permission:", error);
    }
}

// Function to hide the modal
function hideModal() {
    const modal = document.getElementById("protected-content-modal");
    if (modal) {
        modal.remove();
    }
}

// Function to lock the form submission
function lockFormSubmission(form) {
    form.addEventListener("submit", (event) => {
        event.preventDefault(); // Prevent form submission
        showModal(); // Show the modal
    });
}

// Function to unlock the form submission
function unlockFormSubmission() {
    const form = document.getElementById("newsletterForm");
    if (form) {
        form.removeEventListener("submit", lockFormSubmission); // Remove the lock
    }
}

// Event listener to handle form submission locking
document.addEventListener("DOMContentLoaded", async () => {
    const form = document.getElementById("newsletterForm");
    if (form) {
        // Check if push notifications are already granted
        const isGranted = await checkNotificationPermission();
        if (!isGranted) {
            lockFormSubmission(form); // Lock the form submission until permission is granted
        }
    }
});

// Function to detect Safari browser
function isSafari() {
    return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
}
