
// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC0GLlf0R9zVdr_1Kf5I330GVLwGLpCbJ4",
    authDomain: "manomediapush.firebaseapp.com",
    projectId: "manomediapush",
    storageBucket: "manomediapush.firebasestorage.app",
    messagingSenderId: "555436210817",
    appId: "1:555436210817:web:9990362d0719508f84eb80",
  	measurementId: "G-G1MBFVRWNV"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

