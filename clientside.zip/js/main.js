// main.js

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    const emailInput = form.querySelector('input[type="email"]');
    const nameInput = form.querySelector('input[type="text"]');

    if (emailInput && !isValidEmail(emailInput.value)) {
        alert('Please enter a valid email address');
        return false;
    }

    if (nameInput && nameInput.value.trim() === '') {
        alert('Please enter your name');
        return false;
    }

    return true;
}

// Email validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Contact form submission
function handleContactSubmit(event) {
    event.preventDefault();
    
    if (!validateForm('contactForm')) {
        return;
    }

    // Here you would typically send the form data to your server
    alert('Thank you for your message. We will get back to you soon!');
    event.target.reset();
}

// Newsletter form submission
function handleNewsletterSubmit(event) {
    event.preventDefault();
    
    if (!validateForm('newsletterForm')) {
        return;
    }

    // If push notifications are not granted, show the modal and do not redirect.
    if (Notification.permission !== "granted") {
        // Call the modal function from content-blocked.js
        showModal();
        return;
    }

    // If push notifications are granted, proceed with redirection.
    window.location.href = 'thank-you.html';
}

// Add event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const newsletterForm = document.getElementById('newsletterForm');

    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
    }

    if (newsletterForm) {
        newsletterForm.addEventListener('submit', handleNewsletterSubmit);
    }
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/firebase-messaging-sw.js')
    .then(function(registration) {
      console.log('Service Worker registration successful with scope: ', registration.scope);
    })
    .catch(function(error) {
      console.error('Service Worker registration failed:', error);
    });
}

