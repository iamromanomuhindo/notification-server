# Dating 30 Plus - Newsletter Website

A modern, responsive website for capturing email subscriptions and push notifications for dating advice and recommendations for people over 30.

## Table of Contents
- [Setup Instructions](#setup-instructions)
- [Gmail POP3 Configuration](#gmail-pop3-configuration)
- [Firebase Push Notifications Setup](#firebase-push-notifications-setup)
- [Website Structure](#website-structure)
- [Deployment](#deployment)
- [Security Considerations](#security-considerations)

## Setup Instructions

1. Clone or download this repository to your local machine
2. Ensure all files maintain their directory structure:
   ```
   Dating News Letter/
   ├── index.html
   ├── about.html
   ├── newsletter.html
   ├── contact.html
   ├── privacy-policy.html
   ├── terms.html
   ├── styles/
   │   └── main.css
   ├── js/
   │   └── main.js
   ├── js/firebase-config.js
   ├── js/push-notifications.js
   ├── firebase-messaging-sw.js
   └── README.md
   ```

## Gmail POP3 Configuration

### Step 1: Enable POP3 in Gmail

1. Log in to your Gmail account
2. Go to Settings (gear icon) > See all settings
3. Click on the "Forwarding and POP/IMAP" tab
4. In the "POP download" section, select "Enable POP for all mail"
5. Choose what Gmail should do with messages after they're accessed via POP
6. Click "Save Changes"

### Step 2: Configure Gmail Security Settings

1. Go to your Google Account settings
2. Navigate to Security
3. Enable 2-Step Verification if not already enabled
4. Create an App Password:
   - Go to Security > 2-Step Verification
   - Scroll to "App passwords"
   - Select "Mail" and your device
   - Copy the generated 16-character password

### Step 3: POP3 Server Settings

Use these settings in your email configuration:

```
Incoming Mail (POP3) Server:
- Server: pop.gmail.com
- Port: 995
- Requires SSL: Yes
- Username: your-email@gmail.com
- Password: [Your App Password]

Outgoing Mail (SMTP) Server:
- Server: smtp.gmail.com
- Port: 465 (SSL) or 587 (TLS)
- Requires Authentication: Yes
- Username: your-email@gmail.com
- Password: [Your App Password]
```

### Step 4: Contact Form Integration

1. Create a PHP file named `process-form.php` in your root directory
2. Add this code to handle form submissions:

```php
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'path/to/PHPMailer/src/Exception.php';
require 'path/to/PHPMailer/src/PHPMailer.php';
require 'path/to/PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'your-email@gmail.com';
    $mail->Password = 'your-app-password';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    // Recipients
    $mail->setFrom('your-email@gmail.com', 'Dating 30 Plus');
    $mail->addAddress('your-email@gmail.com');

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'New Contact Form Submission';
    $mail->Body = "Name: {$_POST['name']}<br>
                   Email: {$_POST['email']}<br>
                   Subject: {$_POST['subject']}<br>
                   Message: {$_POST['message']}";

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>

## Firebase Push Notifications Setup

### Step 1: Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select an existing one
3. Enable Firebase Cloud Messaging (FCM)

### Step 2: Install Firebase in Your Project

1. Add Firebase SDK to your website:
   ```html
   <!-- Firebase SDK -->
   <script src="https://www.gstatic.com/firebasejs/9.x.x/firebase-app-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/9.x.x/firebase-messaging-compat.js"></script>
   ```

2. Update Firebase configuration in `js/firebase-config.js`:
   ```javascript
   const firebaseConfig = {
       apiKey: "your-api-key",
       authDomain: "your-auth-domain.firebaseapp.com",
       projectId: "your-project-id",
       storageBucket: "your-storage-bucket.appspot.com",
       messagingSenderId: "your-messaging-sender-id",
       appId: "your-app-id"
   };
   ```

### Step 3: Generate VAPID Key

1. In Firebase Console, go to Project Settings
2. Navigate to Cloud Messaging tab
3. Generate a new Web Push certificate (VAPID key)
4. Update the VAPID key in `js/push-notifications.js`

### Step 4: Configure Service Worker

1. Place `firebase-messaging-sw.js` in the root directory
2. Update the Firebase configuration in the service worker
3. Ensure the service worker is registered properly

### Step 5: Backend Integration

Create an API endpoint to store subscription tokens:

```javascript
// Example Node.js/Express endpoint
app.post('/api/subscribe', async (req, res) => {
    try {
        const { token } = req.body;
        
        // Store token in your database
        await db.collection('push_subscriptions').add({
            token,
            timestamp: new Date()
        });
        
        res.status(200).json({ message: 'Subscription successful' });
    } catch (error) {
        res.status(500).json({ error: 'Subscription failed' });
    }
});
```

### Step 6: Sending Push Notifications

Use Firebase Admin SDK to send notifications:

```javascript
const admin = require('firebase-admin');

// Initialize Firebase Admin
admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    projectId: 'your-project-id'
});

// Send notification
async function sendPushNotification(token, title, body) {
    try {
        const message = {
            notification: {
                title,
                body
            },
            token
        };
        
        const response = await admin.messaging().send(message);
        console.log('Successfully sent message:', response);
    } catch (error) {
        console.error('Error sending message:', error);
    }
}

## Website Structure

- `index.html`: Homepage with introduction
- `about.html`: About page with mission statement
- `newsletter.html`: Newsletter signup form with push notification support
- `contact.html`: Contact form with POP3 integration
- `privacy-policy.html`: Privacy policy
- `terms.html`: Terms of service
- `styles/main.css`: All CSS styles
- `js/main.js`: JavaScript for form validation
- `js/firebase-config.js`: Firebase configuration
- `js/push-notifications.js`: Push notification handling
- `firebase-messaging-sw.js`: Service worker for background notifications

## Deployment

1. Upload all files to your web hosting server
2. Ensure PHP is enabled on your server
3. Install PHPMailer using composer or manual installation
4. Update the `process-form.php` with your Gmail credentials
5. Test the contact form and newsletter signup
6. Configure SSL certificate for secure form submissions

## Security Considerations

1. Never commit email credentials to version control
2. Use environment variables for sensitive information
3. Implement CSRF protection on forms
4. Enable SSL/HTTPS for secure data transmission
5. Regularly update dependencies
6. Monitor form submissions for spam

## Support

For any issues or questions, please contact:
- Email: info@dating30plus.com
- Address: 123 Dating Street, Love City, LC 12345

## License

All rights reserved. This project is proprietary and confidential.
